import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import InstrumentoList from './components/InstrumentoList';
import InstrumentoForm from './components/InstrumentoForm';
import InstrumentoDetail from './components/InstrumentoDetail';

function App() {
    return (
        <Router>
            <div>
                <h1>Instrumentos</h1>
                <Switch>
                    <Route path="/" exact component={InstrumentoList} />
                    <Route path="/instrumento/:id" component={InstrumentoDetail} />
                    <Route path="/instrumento/form/:id" component={InstrumentoForm} />
                    <Route path="/instrumento/form" component={InstrumentoForm} />
                </Switch>
            </div>
        </Router>
    );
}

export default App;
