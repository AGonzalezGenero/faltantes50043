import React, { useState, useEffect } from 'react';
import axios from 'axios';

const InstrumentoDetail = ({ match }) => {
    const [instrumento, setInstrumento] = useState(null);

    useEffect(() => {
        axios.get(`http://localhost:8080/api/instrumentos/${match.params.id}`)
            .then(response => setInstrumento(response.data))
            .catch(error => console.error('Error fetching instrumento detail: ', error));
    }, [match.params.id]);

    if (!instrumento) return <div>Loading...</div>;

    return (
        <div>
            <h2>{instrumento.instrumento}</h2>
            <p><strong>Marca:</strong> {instrumento.marca}</p>
            <p><strong>Modelo:</strong> {instrumento.modelo}</p>
            <p><strong>Precio:</strong> ${instrumento.precio}</p>
            <p><strong>Descripción:</strong> {instrumento.descripcion}</p>
            <p><strong>Costo de Envío:</strong> {instrumento.costoEnvio === 'G' ? 'Envío gratis' : instrumento.costoEnvio}</p>
            <img src={instrumento.imagen} alt={instrumento.instrumento} />
        </div>
    );
};

export default InstrumentoDetail;
