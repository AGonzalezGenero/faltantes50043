import React from 'react';

const CategoryFilter = ({ categories, onCategoryChange }) => {
    return (
        <div>
            <label>Filtrar por categoría:</label>
            <select onChange={onCategoryChange}>
                <option value="">Todos</option>
                {categories.map(category => (
                    <option key={category.id} value={category.id}>
                        {category.denominacion}
                    </option>
                ))}
            </select>
        </div>
    );
};

export default CategoryFilter;
