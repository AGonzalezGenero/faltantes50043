import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import CategoryFilter from './CategoryFilter';

const InstrumentoList = () => {
    const [instrumentos, setInstrumentos] = useState([]);
    const [categories, setCategories] = useState([]);
    const [selectedCategory, setSelectedCategory] = useState('');

    // Fetching data from the API
    useEffect(() => {
        axios.get('http://localhost:8080/api/instrumentos')
            .then(response => {
                setInstrumentos(response.data);
            })
            .catch(error => console.error('Error fetching data: ', error));

        axios.get('http://localhost:8080/api/instrumentos/categorias')
            .then(response => setCategories(response.data))
            .catch(error => console.error('Error fetching categories: ', error));
    }, []);

    const handleCategoryChange = (e) => {
        setSelectedCategory(e.target.value);
        if (e.target.value === '') {
            axios.get('http://localhost:8080/api/instrumentos')
                .then(response => setInstrumentos(response.data));
        } else {
            axios.get(`http://localhost:8080/api/instrumentos/categoria/${e.target.value}`)
                .then(response => setInstrumentos(response.data));
        }
    };

    return (
        <div>
            <h2>Instrumentos</h2>
            <CategoryFilter categories={categories} onCategoryChange={handleCategoryChange} />
            <table>
                <thead>
                    <tr>
                        <th>Instrumento</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Precio</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    {instrumentos.map((instrumento) => (
                        <tr key={instrumento.id}>
                            <td>{instrumento.instrumento}</td>
                            <td>{instrumento.marca}</td>
                            <td>{instrumento.modelo}</td>
                            <td>${instrumento.precio}</td>
                            <td>
                                <Link to={`/instrumento/${instrumento.id}`}>Ver Detalles</Link>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default InstrumentoList;
