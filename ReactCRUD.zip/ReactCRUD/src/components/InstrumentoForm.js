import React, { useState, useEffect } from 'react';
import axios from 'axios';

const InstrumentoForm = ({ instrumentoId, history }) => {
    const [instrumento, setInstrumento] = useState({
        instrumento: '',
        marca: '',
        modelo: '',
        imagen: '',
        precio: 0,
        costoEnvio: '',
        cantidadVendida: 0,
        descripcion: '',
        categoria: { id: '' }
    });

    const [categories, setCategories] = useState([]);

    useEffect(() => {
        // Fetch categories
        axios.get('http://localhost:8080/api/instrumentos/categorias')
            .then(response => setCategories(response.data))
            .catch(error => console.error(error));

        if (instrumentoId) {
            // Fetch the selected instrumento if ID is provided
            axios.get(`http://localhost:8080/api/instrumentos/${instrumentoId}`)
                .then(response => setInstrumento(response.data))
                .catch(error => console.error('Error fetching instrumento: ', error));
        }
    }, [instrumentoId]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setInstrumento({ ...instrumento, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (instrumentoId) {
            // Update
            axios.put(`http://localhost:8080/api/instrumentos/${instrumentoId}`, instrumento)
                .then(() => history.push('/'))
                .catch(error => console.error('Error updating instrumento: ', error));
        } else {
            // Create
            axios.post('http://localhost:8080/api/instrumentos', instrumento)
                .then(() => history.push('/'))
                .catch(error => console.error('Error creating instrumento: ', error));
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" name="instrumento" value={instrumento.instrumento} onChange={handleChange} placeholder="Instrumento" required />
            <input type="text" name="marca" value={instrumento.marca} onChange={handleChange} placeholder="Marca" required />
            <input type="text" name="modelo" value={instrumento.modelo} onChange={handleChange} placeholder="Modelo" required />
            <input type="number" name="precio" value={instrumento.precio} onChange={handleChange} placeholder="Precio" required />
            <textarea name="descripcion" value={instrumento.descripcion} onChange={handleChange} placeholder="Descripción"></textarea>
            <select name="categoria" value={instrumento.categoria.id} onChange={handleChange}>
                {categories.map(category => (
                    <option key={category.id} value={category.id}>
                        {category.denominacion}
                    </option>
                ))}
            </select>
            <button type="submit">{instrumentoId ? 'Actualizar' : 'Crear'}</button>
        </form>
    );
};

export default InstrumentoForm;
