import React from 'react';
import ReactDOM from 'react-dom';
import './index.css'; // Puedes usar un archivo CSS para estilos globales si lo deseas
import App from './App'; // El componente principal de la aplicación
import { BrowserRouter as Router } from 'react-router-dom'; // Para poder usar rutas en React

// Renderizamos la aplicación
ReactDOM.render(
  <Router>
    <App />
  </Router>,
  document.getElementById('root')
);
