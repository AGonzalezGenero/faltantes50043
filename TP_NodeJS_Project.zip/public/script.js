const apiUrl = "http://localhost:3000/empleados";

const obtenerEmpleados = async () => {
    const response = await fetch(apiUrl);
    const empleados = await response.json();

    const tableBody = document.querySelector("#empleadosTable tbody");
    tableBody.innerHTML = ''; 

    empleados.forEach(empleado => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${empleado.Legajo}</td>
            <td>${empleado.Apellido}</td>
            <td>${empleado.Nombre}</td>
            <td>${empleado.Dni}</td>
            <td>${empleado.Sector}</td>
            <td>${empleado.FechaIngreso}</td>
            <td>${empleado.Activo ? 'Sí' : 'No'}</td>
            <td>
                <button onclick="editarEmpleado(${empleado.Legajo})">Editar</button>
                <button onclick="eliminarEmpleado(${empleado.Legajo})">Eliminar</button>
            </td>
        `;
        tableBody.appendChild(row);
    });
};

const guardarEmpleado = async (evento) => {
    evento.preventDefault();

    const legajo = document.getElementById('legajo').value;
    const apellido = document.getElementById('apellido').value;
    const nombre = document.getElementById('nombre').value;
    const dni = document.getElementById('dni').value;
    const sector = document.getElementById('sector').value;
    const fechaIngreso = document.getElementById('fechaIngreso').value;
    const activo = document.getElementById('activo').checked;

    const empleado = { Legajo: legajo, Apellido: apellido, Nombre: nombre, Dni: dni, Sector: sector, FechaIngreso: fechaIngreso, Activo: activo };

    if (legajo) {
        await fetch(`${apiUrl}/${legajo}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(empleado)
        });
    } else {
        await fetch(apiUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(empleado)
        });
    }

    document.getElementById('empleadoForm').reset();
    document.getElementById('legajo').value = ''; 
    obtenerEmpleados(); 
};

const editarEmpleado = (legajo) => {
    fetch(`${apiUrl}/${legajo}`)
        .then(response => response.json())
        .then(empleado => {
            document.getElementById('legajo').value = empleado.Legajo;
            document.getElementById('apellido').value = empleado.Apellido;
            document.getElementById('nombre').value = empleado.Nombre;
            document.getElementById('dni').value = empleado.Dni;
            document.getElementById('sector').value = empleado.Sector;
            document.getElementById('fechaIngreso').value = empleado.FechaIngreso;
            document.getElementById('activo').checked = empleado.Activo;
        });
};

const eliminarEmpleado = (legajo) => {
    if (confirm("¿Seguro que quieres eliminar este empleado?")) {
        fetch(`${apiUrl}/${legajo}`, {
            method: 'DELETE',
        }).then(() => obtenerEmpleados()); 
    }
};

document.addEventListener('DOMContentLoaded', obtenerEmpleados);
document.getElementById('empleadoForm').addEventListener('submit', guardarEmpleado);
