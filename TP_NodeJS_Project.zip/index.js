const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const mysql = require("mysql2");
const path = require('path');

const app = express();
app.use(bodyParser.json());
app.use(cors());

const PORT = 3000;

const db = mysql.createConnection({
    host: "localhost",
    user: "tu_usuario",
    password: "tu_contraseña",
    database: "empleadosDB",
});

db.connect((err) => {
    if (err) throw err;
    console.log("Conectado a la base de datos MySQL");
});

app.use(express.static(path.join(__dirname, 'public')));

app.get("/empleados", (req, res) => {
    const sql = "SELECT * FROM Empleado";
    db.query(sql, (err, result) => {
        if (err) throw err;
        res.json(result);
    });
});

app.post("/empleados", (req, res) => {
    const { Legajo, Apellido, Nombre, Dni, Sector, FechaIngreso, Activo } = req.body;
    const sql = "INSERT INTO Empleado SET ?";
    const empleado = { Legajo, Apellido, Nombre, Dni, Sector, FechaIngreso, Activo };
    db.query(sql, empleado, (err, result) => {
        if (err) throw err;
        res.send("Empleado agregado correctamente");
    });
});

app.put("/empleados/:legajo", (req, res) => {
    const legajo = req.params.legajo;
    const { Apellido, Nombre, Dni, Sector, FechaIngreso, Activo } = req.body;
    const sql = `
        UPDATE Empleado 
        SET Apellido = ?, Nombre = ?, Dni = ?, Sector = ?, FechaIngreso = ?, Activo = ?
        WHERE Legajo = ?
    `;
    db.query(sql, [Apellido, Nombre, Dni, Sector, FechaIngreso, Activo, legajo], (err, result) => {
        if (err) throw err;
        res.send("Empleado modificado correctamente");
    });
});

app.delete("/empleados/:legajo", (req, res) => {
    const legajo = req.params.legajo;
    const sql = "DELETE FROM Empleado WHERE Legajo = ?";
    db.query(sql, [legajo], (err, result) => {
        if (err) throw err;
        res.send("Empleado eliminado correctamente");
    });
});

app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
