class Articulo {
    constructor(
        public id: number,
        public descripcion: string,
        public precio: number
    ) {}
}

class DetalleFactura {
    public subtotal: number = 0;

    constructor(
        public articulo: Articulo,
        public cantidad: number
    ) {}

    calcularSubTotal(): number {
        this.subtotal = this.articulo.precio * this.cantidad;
        return this.subtotal;
    }
}

class Factura {
    public detalles: DetalleFactura[] = [];
    public totalItems: number = 0;
    public totalFinal: number = 0;

    constructor(
        public tipoPago: string, // E, TD, TC, CC, TR
        public recargo: number // Porcentaje de recargo
    ) {}

    calcularTotalItems(): number {
        this.totalItems = this.detalles.reduce((total, detalle) => total + detalle.calcularSubTotal(), 0);
        return this.totalItems;
    }

    calcularTotalFinal(): number {
        this.totalFinal = this.calcularTotalItems() + (this.totalItems * (this.recargo / 100));
        return this.totalFinal;
    }
}

class Cliente {
    public facturas: Factura[] = [];

    totalFacturadoXTipoPago(tipoPago: string | null): number {
        return this.facturas
            .filter(factura => !tipoPago || factura.tipoPago === tipoPago)
            .reduce((total, factura) => total + factura.calcularTotalFinal(), 0);
    }
}

// Clase TestB para realizar pruebas
class TestB {
    static main() {
        // Crear artículos
        const articulo1 = new Articulo(1, "Laptop", 1500);
        const articulo2 = new Articulo(2, "Mouse", 50);
        const articulo3 = new Articulo(3, "Teclado", 100);
        const articulo4 = new Articulo(4, "Monitor", 300);
        const articulo5 = new Articulo(5, "Impresora", 200);

        // Crear facturas
        const factura1 = new Factura("E", 5); // Efectivo, recargo 5%
        const factura2 = new Factura("TD", 10); // Tarjeta débito, recargo 10%
        const factura3 = new Factura("CC", 15); // Cuenta corriente, recargo 15%

        // Agregar detalles a las facturas
        factura1.detalles.push(new DetalleFactura(articulo1, 2), new DetalleFactura(articulo2, 3));
        factura2.detalles.push(new DetalleFactura(articulo3, 1), new DetalleFactura(articulo4, 2));
        factura3.detalles.push(new DetalleFactura(articulo5, 5), new DetalleFactura(articulo2, 10));

        // Crear cliente y asignar facturas
        const cliente = new Cliente();
        cliente.facturas.push(factura1, factura2, factura3);

        // Calcular y mostrar resultados
        console.log(`Total facturado (sin filtro): ${cliente.totalFacturadoXTipoPago(null)}`);
        console.log(`Total facturado (Efectivo): ${cliente.totalFacturadoXTipoPago("E")}`);
        console.log(`Total facturado (Tarjeta Débito): ${cliente.totalFacturadoXTipoPago("TD")}`);
        console.log(`Total facturado (Cuenta Corriente): ${cliente.totalFacturadoXTipoPago("CC")}`);
    }
}

// Ejecutar la prueba
TestB.main();
