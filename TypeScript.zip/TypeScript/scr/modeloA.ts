class Detalle {
    constructor(
        public dia: number,
        public kilometros: number
    ) {}
}

class HojaRuta {
    public detalles: Detalle[] = [];

    constructor(
        public fecha: Date,
        public numero: number
    ) {}

    calcularTotalKilometros(): number {
        return this.detalles.reduce((total, detalle) => total + detalle.kilometros, 0);
    }
}

class Vehiculo {
    public hojasRuta: HojaRuta[] = [];

    constructor(
        public patente: string,
        public marca: string,
        public modelo: string
    ) {}

    calcularTotalKilometrosRecorridos(fechaDesde: Date, fechaHasta: Date): number {
        return this.hojasRuta
            .filter(
                hoja => hoja.fecha >= fechaDesde && hoja.fecha <= fechaHasta
            )
            .reduce((total, hoja) => total + hoja.calcularTotalKilometros(), 0);
    }
}

class TestA {
    static main() {
        const vehiculo = new Vehiculo("ABC123", "Toyota", "Corolla");

        const hoja1 = new HojaRuta(new Date("2023-11-01"), 1);
        const hoja2 = new HojaRuta(new Date("2023-11-15"), 2);
        const hoja3 = new HojaRuta(new Date("2023-12-01"), 3);

        hoja1.detalles.push(new Detalle(1, 100), new Detalle(2, 150), new Detalle(3, 200));
        hoja2.detalles.push(new Detalle(1, 50), new Detalle(2, 60), new Detalle(3, 70));
        hoja3.detalles.push(new Detalle(1, 120), new Detalle(2, 130), new Detalle(3, 140));

        vehiculo.hojasRuta.push(hoja1, hoja2, hoja3);

        console.log(`Kilómetros totales hoja 1: ${hoja1.calcularTotalKilometros()} km`);

        const fechaDesde = new Date("2023-11-01");
        const fechaHasta = new Date("2023-11-30");
        console.log(
            `Kilómetros totales recorridos entre ${fechaDesde.toDateString()} y ${fechaHasta.toDateString()}: ${
                vehiculo.calcularTotalKilometrosRecorridos(fechaDesde, fechaHasta)
            } km`
        );
    }
}

TestA.main();
