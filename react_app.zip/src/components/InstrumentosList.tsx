
import React from 'react';
import instrumentos from '../instrumentos.json';

const InstrumentosList: React.FC = () => {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px' }}>
      {instrumentos.instrumentos.map((instrumento) => (
        <div key={instrumento.id} style={{ border: '1px solid #ccc', padding: '16px', borderRadius: '8px' }}>
          <img src={instrumento.imagen} alt={instrumento.instrumento} style={{ width: '100%' }} />
          <h2>{instrumento.instrumento}</h2>
          <p><strong>Marca:</strong> {instrumento.marca}</p>
          <p><strong>Modelo:</strong> {instrumento.modelo}</p>
          <p><strong>Precio:</strong> ${instrumento.precio}</p>
          <p>
            <strong>Envío:</strong> {instrumento.costoEnvio === 'G' ? 'Envío gratis a todo el país' : `$${instrumento.costoEnvio}`}
          </p>
          <p><strong>Cantidad vendida:</strong> {instrumento.cantidadVendida}</p>
          <p>{instrumento.descripcion}</p>
        </div>
      ))}
    </div>
  );
};

export default InstrumentosList;
