
import React from 'react';
import InstrumentosList from './components/InstrumentosList';

const App: React.FC = () => {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Instrumentos Musicales</h1>
      </header>
      <main>
        <InstrumentosList />
      </main>
    </div>
  );
};

export default App;
